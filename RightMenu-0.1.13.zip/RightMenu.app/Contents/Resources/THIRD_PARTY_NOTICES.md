# Third-Party Notices

## Apache Tika test documents

The blank Pages, Numbers, and Keynote templates in
`Sources/RightMenuCore/Resources` are generated from test documents in Apache
Tika, pinned by `script/generate_iwork_templates.py`. The generator removes the
fixture content and previews before producing the bundled templates.

Apache Tika is licensed under the Apache License, Version 2.0. A copy is
included at `LICENSES/Apache-2.0.txt`.
